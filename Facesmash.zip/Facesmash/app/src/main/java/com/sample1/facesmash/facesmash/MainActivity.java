package com.sample1.facesmash.facesmash;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private boolean bb;
   private MediaPlayer mplayer;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar =(Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDefaultDisplayHomeAsUpEnabled(true);
    }
    public void stop()
    {
        if (mplayer!=null){
            mplayer.release();
            mplayer=null;
        }
    }
    public void a(View v)
    {
        Toast.makeText(this,"happy",Toast.LENGTH_LONG).show();
        int k=1;
        Intent intent = new Intent(MainActivity.this,musicpalyer.class);
        intent.putExtra("key",k);
        startActivity(intent);
    }

    public void b(View v)
    {   Toast.makeText(this,"sad",Toast.LENGTH_LONG).show();
        int k=2;
        Intent intent = new Intent(MainActivity.this,musicpalyer.class);
        intent.putExtra("key",k);
        startActivity(intent);
    }
    public void c(View v)
    {   Toast.makeText(this,"angry",Toast.LENGTH_LONG).show();
        int k=3;
        Intent intent = new Intent(MainActivity.this,musicpalyer.class);
        intent.putExtra("key",k);
        startActivity(intent);
    }
    public void d(View v)
    {
        Toast.makeText(this,"fear",Toast.LENGTH_LONG).show();
        int k=4;
        Intent intent = new Intent(MainActivity.this,musicpalyer.class);
        intent.putExtra("key",k);
        startActivity(intent);;
    }
    public void e(View v)
    {    Toast.makeText(this,"neutral",Toast.LENGTH_LONG).show();
        int k=5;
        Intent intent = new Intent(MainActivity.this,musicpalyer.class);
        intent.putExtra("key",k);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        if(!bb)
        {
            Toast.makeText(this,"press back again to exit",Toast.LENGTH_LONG).show();
            bb=true;
            stop();
        }
        else {
            super.onBackPressed();
        }
        new CountDownTimer(3000,1000){
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                bb=false;
            }
        }.start();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id =item.getItemId();
        if(id==R.id.settings_id)
        {
        startActivity(new Intent(this,Main2Activity.class));
        }
        return super.onOptionsItemSelected(item);
    }
}
